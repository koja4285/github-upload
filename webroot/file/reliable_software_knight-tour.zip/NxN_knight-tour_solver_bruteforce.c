/* This program solves The Knight's tour using brute-force algorithm.
 * This program finds closed tour.
 * N, the size of the board, should be less than 10.
 * However, since this applys brute-force, it doesn't probably stop with big number.
 * */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>

#define N 6
#define NUM_OF_DEST 8

const int dj[NUM_OF_DEST] = { -1,-2,-2,-1, 1, 2, 2, 1 };
const int dk[NUM_OF_DEST] = {  2, 1,-1,-2,-2,-1, 1, 2 };
int startj = 1;
int startk = 1;
int board[10*10] = { 0 };

/* Returns true if (j, k) is not visited
 * and (j, k) is on the board.
 * */
bool isValidSquare(int j, int k) {
	return (!board[10*j + k]) && (1 <= j && j <= N) && (1 <= k && k <= N);
}

/* Returns true if (j,k) is on the board. */
bool isOnTheBoard(int j, int k) {
	return (1 <= j && j <= N) && (1 <= k && k <= N);
}

/* Returns if the Knight can go back to the starting position
 * from the end position.
 * */
bool isClosed(int j, int k) {
	int n, nextj, nextk;
	for(n = 0; n < NUM_OF_DEST; n++) {
		nextj = startj + dj[n];
		nextk = startk + dk[n];
		if(isOnTheBoard(nextj, nextk) && (nextj == j) && (nextk == k)) return true;
	}
	return false;
}

/* Prints the board. */
void print() {
	int n, m;
	for(n = 1; n <= N; n++) {
		for(m = 1; m <= N; m++) {
			printf("\t%3d", board[10*n + m]);
		}
		printf("\n");
	}
}

/* Finds if there's Knight's tour or not.
 * Returns true immediately if it finds one.
 * i, j, k represents the location (j,k) at time i
 * 1 <= i <= N*N
 * 1 <= j, k <= N
 * */
bool findKnightsTour(int i, int j, int k) {
	//printf("line number: %d, i: %d, (j,k): (%d,%d)\n", __LINE__, i, j, k);
	int n;
	board[10*j + k] = i;
	if(i == N*N) {
		if(isClosed(j, k)) return true;
		board[10*j + k] = 0;
		return false;
	}
	for(n = 0; n < NUM_OF_DEST; n++) {
		if(isValidSquare(j+dj[n], k+dk[n])) {
			if(!findKnightsTour(i+1, j+dj[n], k+dk[n])) {
				continue;
			}
			return true;
		}
	}
	board[10*j + k] = 0;
	return false;
}

void board_reset() {
	int j, k;
	for(j = 1; j <= N; j++) {
		for(k = 1; k <= N; k++) {
			board[10*j + k] = 0;
		}
	}
}

void cal_ave(double cal_time[]) {
	int j, k;
	double sum = 0;
	int count = 0;
	for(j = 1; j <= N; j++) {
		for(k = 1; k <= N; k++) {
			if(cal_time[j*N + k]) {
				sum += cal_time[j*N + k];
				count++;
			}
		}
	}
	printf("Average calculation time: %lf [s]\n", sum/count);
}

int main(int argc, char* argv[]) {
	clock_t start, end;
	int j, k;
	int option;
	double cal_time[(N+1)*(N+1)] = {0};

	if(argc == 1) {
		fprintf(stderr, "Usage: ./brute_force <1-3> [starting postion]\n");
		fprintf(stderr, "1: Random Starting Position\n");
		fprintf(stderr, "2: Entered Starting Position\n");
		fprintf(stderr, "3: All Starting Position\n");
		exit(1);
	}
	option = atoi(argv[1]);
	if(option == 1) {
		srand(time(NULL));
		startj = rand()%N + 1;
		startk = rand()%N + 1;
		start = clock();
		if(!findKnightsTour(1,startj,startk)) {
			fprintf(stderr, "The Knight's tour faild!!\n");
			exit(1);
		}
		end = clock();
		printf("Starting Position: (%d, %d)\n", startj, startk);
		printf("The Knight's tour ends successfully!!\n");
		printf("Calculation time: %lf [s]\n", ((double) end - start) / CLOCKS_PER_SEC);
		print();
	} else if (option == 2) {
		startj = atoi(argv[2]);
		startk = atoi(argv[3]);
		if(!(1 <= startj && startj <= N && 1 <= startk && startk <= N)) {
			fprintf(stderr, "Starting Position's range should be [1,%d]\n", N);
			exit(1);
		}
		start = clock();
		if(!findKnightsTour(1,startj,startk)) {
			fprintf(stderr, "The Knight's tour faild!!\n");
			exit(1);
		}
		end = clock();
		printf("The Knight's tour ends successfully!!\n");
		printf("Calculation time: %lf [s]\n", ((double) end - start) / CLOCKS_PER_SEC);
		print();
	} else if (option == 3) {
		for(startj = 1; startj <= N; startj++) {
			for(startk = 1; startk <= N; startk++) {
				board_reset();
				start = clock();
				if(!findKnightsTour(1,startj,startk)) {
					printf("Staring Position (%d, %d): The Knight's tour failed\n", startj, startk);
					continue;
				}
				end = clock();
				printf("Staring Position (%d, %d): Calculation time: %lf [s]\n", startj, startk, (cal_time[startj*N+startk] = ((double) end - start) / CLOCKS_PER_SEC));
			}
		}
		cal_ave(cal_time);
	}
}
