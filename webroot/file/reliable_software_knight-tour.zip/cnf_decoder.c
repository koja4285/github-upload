#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
	FILE *fp;
	FILE *fp2;
	const char * input = argv[1];
	const char * output = "solution.sol";
	int var;

	if (argc != 2) {
		fprintf(stderr, "Usage: %s <cnf file>\n", argv[0]);
		exit(1);
	}

	if((fp = fopen(input, "r")) == NULL) {
		fprintf(stderr, "opening a file error");
		exit(1);
	}
	if((fp2 = fopen(output, "w")) == NULL) {
		fprintf(stderr, "opening a file error");
		exit(1);
	}
	while((fscanf(fp, "%d", &var)) != EOF) {
		if(var > 0) fprintf(fp2, "%5d ", var);
	}
	fclose(fp);
	fclose(fp2);
	printf("The file \"%s\" is created.\n", output);
	return 0;
}
