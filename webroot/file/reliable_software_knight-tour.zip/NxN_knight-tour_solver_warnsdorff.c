/* **************************このプログラムについて**************************
 * 高信頼ソフトウェアの課題として作成したけども題意を間違えて作ってしまった。
 * このプログラム自体はWarnsdorff's ruleにしたがってNxNのナイトツアーを解くプログラムである。
 * */
/* This program solves The Knight Tour Problem using Warnsdorff's rule.
 * Tie breaking rule adopts Arnd Roth's method.
 * The first position is random.
 * */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>

#define N 8
#define NUM_OF_DEST 8

const int dj[NUM_OF_DEST] = { -1,-2,-2,-1, 1, 2, 2, 1 };
const int dk[NUM_OF_DEST] = {  2, 1,-1,-2,-2,-1, 1, 2 };
const double center_j = N/2;
const double center_k = N/2;
int x[N*N*N*N];

/* i, j, k represents the location (j+1,k+1) at time i+1
 * 0 <= i <= N*N -1
 * 0 <= j, k <= N - 1
 * */
int i = 0; int j = 0; int k = 0;

/* Writes the content of 'str' on cnf file */
void write(char str[], FILE *fp) {
	char *p;
	p = str;
	while(*p) {
		if(fputc(*p++, fp) == EOF) {
			fprintf(stderr, "wrting error");
			exit(1);
		}
	}
}

/* Negates all the variables at time i+1. */
void negate() {
	int m, n;
	for(m = 0; m < N; m++) {
		for(n = 0; n < N; n++) {
			x[(N*N*i) + (N*m) + n] = 0;
		}
	}
}

/* Returns true if (p+1, q+1) is not visited
 * and (p+1, q+1) is within the board.
 * */
bool isValidSquare(int p, int q) {
	int n;
	bool isVisited = false;
	for(n = 0; n <= i; n++) {
		if(x[(N*N*n) + (N*p) + q]) isVisited = true;
	}
	return !isVisited && (0 <= p && p <= N-1) && (0 <= q && q <= N-1);
}

/* Retruns the number of moves that the Knight could
 * make from the square.
 * */
int getDgree(int p, int q) {
	int n, count = 0;
	for(n = 0; n < NUM_OF_DEST; n++) {
		if(isValidSquare(p + dj[n], q + dk[n])) count++;
	}
	return count;
}

/* Calculates euclidean distance from the center of the board. */
double distance(int p, int q) {
	return (p - center_j) * (p - center_j) + (q - center_k) * (q - center_k);
}

/* Decides which square to go next.
 * Follows Warnsdorff's rule.
 * If there's no more next square, j and k becomes -1.
 * Applys Arnd Roth's method as tie breaking rule.
 * */
void decideNextSquare() {
	int n, j_candidate, k_candidate, degree, min_degree = (NUM_OF_DEST+1);
	int next_j = -1, next_k = -1;
	for(n = 0; n < NUM_OF_DEST; n++) {
		j_candidate = j + dj[n];
		k_candidate = k + dk[n];
		if(isValidSquare(j_candidate, k_candidate) && (degree = getDgree(j_candidate, k_candidate)) <= min_degree) {
			if(degree < min_degree) {
				next_j = j_candidate;
				next_k = k_candidate;
				min_degree = degree;
			} else if (degree == min_degree) {
				double candidate_distance = distance(j_candidate, k_candidate);
				double next_distance = distance(next_j, next_k);
				if(candidate_distance > next_distance) {
					next_j = j_candidate;
					next_k = k_candidate;
				}
			}
		}
	}
	j = next_j;
	k = next_k;
}


/**
 * Print out the result.
 */
void print(int result[N][N]) {
	int i, j = 0;
	for (int i = 0; i < N; ++i) {
		for (int j = 0; j < N; ++j) {
			printf("\t%3d", result[i][j]);
		}
		puts("");
	}
}

int main() {
	char firstLine[16];
	char vars[N*N*10]; // All the variables at time i+1.
	int result[N][N];
	int m, n;
	FILE *fp; // my own cnf file named 'a3p1.cnf'
	const char * outputFilename = "NxN_knight-tour_warnsdorff.cnf";
	if((fp = fopen(outputFilename, "w")) == NULL) {
		fprintf(stderr, "opening a file error");
		exit(1);
	}

	/* Writes the first line. 
	 * Number of variable is N*N*N*N.
	 * Number of clauses is N*N.
	 */
	sprintf(firstLine, "p cnf %d %d\n", N*N*N*N, N*N);
	write(firstLine, fp);

	/* Finds the Knight's tour starting from random position. */
	srand(time(NULL));
	j = rand() % N; k = rand() % N;
	for(i = 0; i < N*N; i++) {
		result[j][k] = i+1;
		// printf("Current Position: (%d, %d), time: %d\n", j+1, k+1, i+1);
		negate();

		x[(N*N*i) + (N*j) + k] = 1;

		strcpy(vars, "");
		for(m = 0; m < N; m++) {
			for(n = 0; n < N; n++) {
				int num = x[(N*N*i) + (N*m) + n];
				int var = (10*10*(i+1)) + (10*(m+1)) + (n+1);
				if(!num) var = -var;
				char var_str[20];
				sprintf(var_str, "%d", var);
				strcat(vars, var_str);
				strcat(vars, " ");
			}
		}
		strcat(vars, "0\n\0");
		write(vars, fp);

		if(i != N*N-1) decideNextSquare();
		if(j == -1 && k == -1) {
			fprintf(stderr, "The Knight's tour failed!!\n");
			exit(1);
		}
	}


	fclose(fp);
	print(result);
	printf("The file \"%s\" is created.\n", outputFilename);
	printf("The Knight's tour ends successfully!!\n");
}
