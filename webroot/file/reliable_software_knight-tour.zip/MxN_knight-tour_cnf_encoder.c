/**
 * This program encodes MxN The KKnight's tour problem into cnf file.
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>

#define M 5
#define N 8
#define NUM_OF_DEST 8

const int dj[NUM_OF_DEST] = { -1,-2,-2,-1, 1, 2, 2, 1 };
const int dk[NUM_OF_DEST] = {  2, 1,-1,-2,-2,-1, 1, 2 };
int startj = 1;
int startk = 1;
int previous[10*10] = {0};
int next[10*10] = {0};
FILE *fp; // my own cnf file named 'a3p1.cnf'
const char * outputFilename = "MxN_knight-tour.cnf";

/* Writes the content of 'str' on cnf file */
void write(char str[], FILE *fp) {
	char *p;
	p = str;
	while(*p) {
		if(fputc(*p++, fp) == EOF) {
			fprintf(stderr, "wrting error");
			exit(1);
		}
	}
}

/* Returns true if (j, k) is on the board.
 * */
bool isValidSquare(int j, int k) {
	return (1 <= j && j <= M) && (1 <= k && k <= N);
}

/* contraint 1
 * At each time i, the Knight is at some square but not at more than two squares at the same time.
 * (x_ijk*x_imn)'   (jk != mn);
 * */
void c1() {
	int i, j, k, m, n;
	char str[256];
	for(i = 1; i <= M*N; i++) {
		strcpy(str, "");
		for(j = 1; j <= M; j++) {
			for(k = 1; k <= N; k++) {
				char num[8];
				sprintf(num, "%d%d%d ", i, j, k);
				strcat(str, num);
			}
		}
		strcat(str, "0\n");
		write(str, fp);

		for(j = 1; j <= M; j++) {
			for(k = 1; k <= N; k++) {
				for(m = j; m <= M; m++) {
					if(m == j) {
						for(n = k+1; n <= N; n++) {
							sprintf(str, "-%d%d%d -%d%d%d 0\n", i, j, k, i, m, n);
							write(str, fp);
						}
					} else {
						for(n = 1; n <= N; n++) {
							sprintf(str, "-%d%d%d -%d%d%d 0\n", i, j, k, i, m, n);
							write(str, fp);
						}
					}
				}
			}
		}
	}
}

void reset_next() {
	int i, j;
	for(i = 1; i <= M; i++) {
		for(j = 1; j <= N; j++) {
			next[10*i + j] = 0;
		}
	}
}

bool isClosed(int j, int k, int m, int n) {
	int i, nextj, nextk;
	for(i = 0; i < NUM_OF_DEST; i++) {
		nextj = j + dj[i];
		nextk = k + dk[i];
		if(isValidSquare(nextj, nextk) && (nextj == m) && (nextk == n)) return true;
	}
	return false;
}

/* contraint 2
 * When the Knight is at (j,k) at time i, it can go to at most 8 squares at time i+1.
 * And it should choose one of them.
 * */
void c2() {
	int i, j, k, n, m;
	char str[256];
	for(i = 1; i <= M*N-1; i++) {
		memcpy(previous, next, sizeof(next));
		reset_next();
		if(i == 1) {
			previous[10*startj + startk] = 1;
		}

		for(j = 1; j <= M; j++) {
			for(k = 1; k <= N; k++) {
				if(previous[10*j + k] == 1) {
					for(n = 0; n < NUM_OF_DEST; n++) {
						if(isValidSquare(j+dj[n], k+dk[n])) {
							next[10*(j+dj[n]) + (k+dk[n])] = 1;
						}
					}
				}
			}
		}

		strcpy(str, "");
		for(j = 1; j <= M; j++) {
			for(k = 1; k <= N; k++) {
				if(next[10*j + k] == 1) {
					char num[8];
					sprintf(num, "%d%d%d ", i+1, j, k);
					strcat(str, num);
				}
			}
		}
		strcat(str, "0\n");
		write(str, fp);

		for(j = 1; j <= M; j++) {
			for(k = 1; k <= N; k++) {
				if(previous[10*j + k] == 1) {
					for(m = 1; m <= M; m++) {
						for(n = 1; n <= N; n++) {
							if(next[10*m + n] == 1) {
								if(!isClosed(j, k, m, n)) {
									sprintf(str, "-%d%d%d -%d%d%d 0\n", i, j, k, i+1, m, n);
									write(str, fp);
								}
							}
						}
					}
				}
			}
		}

		for(j = 1; j <= M; j++) {
			for(k = 1; k <= N; k++) {
				if(next[10*j + k] == 1) {
					for(m = j; m <= M; m++) {
						if(m == j) {
							for(n = k+1; n <= N; n++) {
								if(next[10*m + n] == 1) {
									sprintf(str, "-%d%d%d -%d%d%d 0\n", i+1, j, k, i+1, m, n);
									write(str, fp);
								}
							}
						} else {
							for(n = 1; n <= N; n++) {
								if(next[10*m + n] == 1) {
									sprintf(str, "-%d%d%d -%d%d%d 0\n", i+1, j, k, i+1, m, n);
									write(str, fp);
								}
							}
						}
					}
				}
			}
		}
	}
}

/* contraint 3
 * If the Knight is at (j,k) at time i, it should not be in (j,k) at any other time t.
 * (x_ijk*x_tjk)  (for 1 <= i, t <= M*N, i != t)
 * */
void c3() {
	int i, t, j, k;
	char str[256];
	for(j = 1; j <= M; j++) {
		for(k = 1; k <= N; k++) {
			strcpy(str, "");
			for(i = 1; i <= M*N; i++) {
				char num[8];
				sprintf(num, "%d%d%d ", i, j, k);
				strcat(str, num);
			}
			strcat(str, "0\n");
			write(str, fp);

			for(i = 1; i <= M*N-1; i++) {
				for(t = i+1; t <= M*N; t++) {
					sprintf(str, "-%d%d%d -%d%d%d 0\n", i, j, k, t, j, k);
					write(str, fp);
				}
			}
		}
	}
}

/* contraint 4
 * This Knight's tour is closed tour.
 * The Knight can go back to start position from end position.
 * */
void c4() {
	char str[64];
	int finalj[NUM_OF_DEST] = {0};
	int finalk[NUM_OF_DEST] = {0};
	int n, m;
	sprintf(str, "1%d%d 0\n", startj, startk);
	write(str, fp);
	strcpy(str, "");
	for(n = 0; n < NUM_OF_DEST; n++) {
		if(isValidSquare(startj+dj[n], startk+dk[n])) {
			finalj[n] = startj + dj[n];
			finalk[n] = startk + dk[n];
			char num[8];
			sprintf(num, "%d%d%d ", M*N, startj+dj[n], startk+dk[n]);
			strcat(str, num);
		}
	}
	strcat(str, "0\n");
	write(str, fp);
	for(n = 0; n < NUM_OF_DEST-1; n++) {
		if(finalj[n]) {
			for(m = n+1; m < NUM_OF_DEST; m++) {
				if(finalj[m]) {
					sprintf(str, "-%d%d%d -%d%d%d 0\n", M*N, finalj[n], finalk[n], M*N, finalj[m], finalk[m]);
					write(str, fp);
				}
			}
		}
	}
}

int num_of_line() {
	char buf[64];
	int line = 0;
	rewind(fp);
	while(fgets(buf, 64, fp) != NULL) line++;
	return line;
}

int main(int argc, char* argv[]) {
	char firstLine[32];
	int option;
	if((fp = fopen(outputFilename, "w+")) == NULL) {
		fprintf(stderr, "opening a file error");
		exit(1);
	}

	if(argc == 1) {
		fprintf(stderr, "Usage: %s <1-3> [starting postion]\n", argv[0]);
		fprintf(stderr, "1: Random Starting Position\n");
		fprintf(stderr, "2: Entered Starting Position\n");
		exit(1);
	}
	option = atoi(argv[1]);
	if(option == 1) {
		srand(time(NULL));
		startj = rand()%M + 1;
		startk = rand()%N + 1;
	} else if (option == 2) {
		startj = atoi(argv[2]);
		startk = atoi(argv[3]);
		if(!(1 <= startj && startj <= M && 1 <= startk && startk <= N)) {
			fprintf(stderr, "(j,k) should be (1<=j<=%d) ^ (1<=k<=%d)\n", M, N);
			exit(1);
		}
	}
	c1();  // contraint 1
	c2();  // contraint 2
	c3();  // contraint 3
	c4();  // contraint 4

	fclose(fp);
	printf("the file \"%s\" is created.\n", outputFilename);
	return 0;
}
