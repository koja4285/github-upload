#include <stdio.h>      /* for printf() and fprintf() */
#include <sys/socket.h> /* for socket(), bind(), and connect() */
#include <arpa/inet.h>  /* for sockaddr_in and inet_ntoa() */
#include <stdlib.h>     /* for atoi() and exit() */
#include <string.h>     /* for memset() */
#include <unistd.h>     /* for close() */
#include <pthread.h>    /* for pthread_*() */

#define MAXPENDING 5    /* Maximum outstanding connection requests */
#define TOTALCLIENTS 2
#define MAXANSNUM 5
#define MAXANSLENGTH 16

int current = 0;                              /* current index for words[] */
int sock_i = 0;                               /* index for sockfd[] */
int sockfd[TOTALCLIENTS];
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
int doCheck;                                  /* flag for if answer should be checked */
char words[MAXANSNUM][MAXANSLENGTH];          /* word answers */
int points[TOTALCLIENTS] = {0};
int hintIndex[TOTALCLIENTS] = {1};

void DieWithError(char *errorMessage);  /* Error handling function */
static void *doit(void *);             
void getAnswer(int connfd);
int checkAnswer(char* ans);
void notify(int connfd);
void fill(int *, int, int);
// void getRanking(int *, int *);

int main(int argc, char *argv[])
{
	int servSock;                    /* Socket descriptor for server */
	int *clntSock;                   /* pointer to Socket descriptor for client */
	struct sockaddr_in servAddr;     /* Local address */
	struct sockaddr_in clntAddr;     /* Client address */
	unsigned short servPort;         /* Server port */
	unsigned int clntLen;            /* Length of client address data structure */
	pthread_t tid[TOTALCLIENTS];     /* thread id */

	if (argc != 2)     /* Test for correct number of arguments */
	{
		fprintf(stderr, "Usage:  %s <Server Port>\n", argv[0]);
		exit(1);
	}

	/* Create word list, randomly takes pokemon names. */
	FILE *fp = fopen("pokemon.txt", "r");
	int totalLine = 0;
	char c;
	do {
		c = getc(fp);
		if (c == '\n' || c == EOF) {
			++totalLine;
		}
	} while(c != EOF);

	// load all the polemon names
	rewind(fp);
	char pokemons[totalLine][MAXANSLENGTH];
	int i = 0;
	for (i = 0; i < totalLine; ++i) {
		fgets(pokemons[i], MAXANSLENGTH-1, fp);
	}
	fclose(fp);
	
	// randomly inserts MAXANSNUM numbers of pokemons into words
	time_t t;
	srand((unsigned) time(&t));
	for (i = 0; i < MAXANSNUM; ++i) {
		int randomIndex = rand() % totalLine;
		strncpy(words[i], pokemons[randomIndex], strlen(pokemons[randomIndex])-1);
	}


	servPort = atoi(argv[1]);  /* First arg: local port */

	/* Create socket for incoming connections */
	if ((servSock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)
		DieWithError("socket() failed");

	/* Construct local address structure */
	memset(&servAddr, 0, sizeof(servAddr));       /* Zero out structure */
	servAddr.sin_family = AF_INET;                /* Internet address family */
	servAddr.sin_addr.s_addr = htonl(INADDR_ANY); /* Any incoming interface */
	servAddr.sin_port = htons(servPort);          /* Local port */

	/* Bind to the local address */
	if (bind(servSock, (struct sockaddr *) &servAddr, sizeof(servAddr)) < 0)
		DieWithError("bind() failed");

	/* Mark the socket so it will listen for incoming connections */
	if (listen(servSock, MAXPENDING) < 0)
		DieWithError("listen() failed");

	/* run untill the number of clients reaches TOTALCLIENTS */
	printf("waiting for clients to connect.....\n");
	while(sock_i != TOTALCLIENTS)
	{
		/* Set the size of the in-out parameter */
		clntLen = sizeof(clntAddr);

		if( (clntSock = malloc(clntLen)) == NULL ) {
			DieWithError("malloc() failed");
		}

		/* Wait for a client to connect */
		if ((*clntSock = accept(servSock, (struct sockaddr *) &clntAddr, 
						&clntLen)) < 0)
			DieWithError("accept() failed");

		sockfd[sock_i++] = *clntSock;

		/* clntSock is connected to a client! */
		printf("Handling client %s, sockfd: %d\n", inet_ntoa(clntAddr.sin_addr), *clntSock);
		free(clntSock);
	}

	while(1) {
		int i;
		char message[64];
		int msgSize;
		int hintIndexSize = (int)(sizeof(hintIndex) / sizeof(*hintIndex));

		fill(hintIndex, 1, hintIndexSize);
		/* iterate sockfd[] to send question and create thread */
		for(i = 0; i < TOTALCLIENTS; i++) {
			/* allocating memory for clntsock */
			if( (clntSock = malloc(clntLen)) == NULL ) {
				DieWithError("malloc() failed");
			}
			*clntSock = sockfd[i];
			sprintf(message, "[Q%d/%d] %c, %lu",
					current+1, MAXANSNUM, words[current][0], strlen(words[current]));
			msgSize = strlen(message);
			if (send(sockfd[i], message, msgSize, 0) != msgSize)
				DieWithError("send() failed");

			pthread_create(&tid[i], NULL, &doit, clntSock);

		}

		/* wait for all threads */
		for(i = 0; i < TOTALCLIENTS; i++) {
			pthread_join(tid[i], NULL);
		}

		/* 終了時にクライアントに得点をいう */
		if(current == MAXANSNUM) {
			// int ranking[TOTALCLIENTS];
			for(i = 0; i < TOTALCLIENTS; i++) {
				// getRanking(points, ranking);
				sprintf(message, "TOTAL POINT: %d\n", points[sockfd[i] % TOTALCLIENTS]);
				msgSize = strlen(message);
				if (send(sockfd[i], message, msgSize, 0) != msgSize)
					DieWithError("send() failed");
			}
			break;
		}
	}
	pthread_mutex_destroy(&lock);

	return 0;
}

/* notify all clients but one which corrected */
void notify(int connfd)
{
	int i;
	char message[64];
	unsigned int msgSize;

	strcpy(message, "!!!他のクライアントが先に正解しました!!!");
	msgSize = strlen(message);
	for(i = 0; i < TOTALCLIENTS; i++) {
		/* don't send to the client which corrected */
		if(sockfd[i] != connfd) { 
			if( send(sockfd[i], message, msgSize, 0) != msgSize ) {
				DieWithError("in notify() send() failed");
			}
		}
	}
}

/* ここから下の関数はマルチスレッドで実行する */
static void* doit(void *arg)
{
	int connfd;
	connfd = *( (int *) arg );
	free(arg);
	getAnswer(connfd);
	printf("returning NULL\n");
	return NULL;
}

void getAnswer(int connfd)
{
	char ans[MAXANSLENGTH];
	char message[64];
	char question[15];
	int bytesRecvd;
	unsigned int msgSize;
	int wordLength = (int) strlen(words[current]);
	int i = 0;
	char hint[wordLength+1];
	int digit;             /* 1 for 正解, 0 for 間違い, 2 for hint */
	doCheck = 1;           /* 1 for check, 0 for do not check */

	for(;;) {
		/* Receive answer from client */
		if ( (bytesRecvd = recv(connfd, ans, MAXANSLENGTH-1, 0)) <= 0 ) {
			DieWithError("in getAnswer() : recv() failed");
		}
		ans[bytesRecvd-1] = '\0';            /* modify '\n' to '\0' */
		printf("Received from %d: %s$\n", connfd, ans);

		pthread_mutex_lock(&lock);
		if(doCheck) {
			digit = checkAnswer(ans);
			switch (digit) {
				case 0: // wrong answer
					strcpy(message, "間違い");
					points[connfd%TOTALCLIENTS] -= 2;
					break;

				case 1: // correct answer
					doCheck = 0;
					strcpy(message, "正解");
					notify(connfd);
					points[connfd%TOTALCLIENTS] += 3;
					break;

				case 2: // hint
					if (hintIndex[connfd % TOTALCLIENTS] >= wordLength)
						break;
					// point is decremented
					points[connfd % TOTALCLIENTS] -= 1;
					for (i = 0; i < wordLength; ++i) {
						hint[i] = (i <= hintIndex[connfd % TOTALCLIENTS]) ? words[current][i] : '_';
					}
					hint[wordLength] = '\0';
					printf("hint: %s\n", hint);
					++hintIndex[connfd % TOTALCLIENTS];
					sprintf(message, "[Q%d/%d] %s\n", current+1, MAXANSNUM, hint);
					break;
			}
			msgSize = strlen(message);
			if( send(connfd, message, msgSize, 0) != msgSize ) {
				DieWithError("in getAnswer(): send() failed");
			}
			pthread_mutex_unlock(&lock);
			if(digit == 1) break;
		} else {                             /* skip checking as one client corrected */
			pthread_mutex_unlock(&lock);
			break;
		}
	}
}

int checkAnswer(char *ans)
{
	printf("checking.........................................\n");
	sleep(3);

	// HINT
	if (!strcmp(ans, "hint")) {
		return 2;
	}

	if(!strcmp(ans, words[current])) {
		current++;
		return 1;
	}

	return 0;
}


/* fill the array with specified number */
void fill(int arr[], int num, int size)
{
	int i = 0;
	for (i = 0; i < size; ++i) {
		arr[i] = num;
	}
}


/* Get rankings of each clients based on points */
//void getRanking(int* ranking, int* points)
//{
//
//}
