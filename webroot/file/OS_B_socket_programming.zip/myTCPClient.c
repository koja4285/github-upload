#include <stdio.h>      /* for printf() and fprintf() */
#include <sys/socket.h> /* for socket(), connect(), send(), and recv() */
#include <arpa/inet.h>  /* for sockaddr_in and inet_addr() */
#include <stdlib.h>     /* for atoi() and exit() */
#include <string.h>     /* for memset() */
#include <unistd.h>     /* for close() */
#include <pthread.h>    /* for pthread_*() */
#include <signal.h>     /* for pthread_kill() */

#define RCVBUFSIZE 64   /* Size of receive buffer */
#define MAXANSLENGTH 16 /* Size of answer */

void DieWithError(char *errorMessage);  /* Error handling function */
static void* sendAnswer(void* arg);

int main(int argc, char *argv[])
{
    int sock;                        /* Socket descriptor */
    struct sockaddr_in servAddr;     /* server address */
    unsigned short servPort;         /* server port */
    char *servIP;                    /* Server IP address (dotted quad) */
    char buffer[RCVBUFSIZE];         /* buffer for  string */
    int bytesRcvd;                   /* Bytes read in single recv() */
    int *clntSock;
    pthread_t tid;                   /* thread ID */
    
    if ((argc < 2) || (argc > 3))    /* Test for correct number of arguments */
    {
        fprintf(stderr, "Usage: %s <Server IP> <Port>\n", argv[0]);
        exit(1);
    }
    
    servIP = argv[1];             /* First arg: server IP address (dotted quad) */
    
    if (argc == 3)
        servPort = atoi(argv[2]); /* Use given port, if any */
    else
        DieWithError("invalid port");
    
    /* Create a reliable, stream socket using TCP */
    if ((sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)
        DieWithError("socket() failed");
    
    /* Construct the server address structure */
    memset(&servAddr, 0, sizeof(servAddr));         /* Zero out structure */
    servAddr.sin_family      = AF_INET;             /* Internet address family */
    servAddr.sin_addr.s_addr = inet_addr(servIP);   /* Server IP address */
    servAddr.sin_port        = htons(servPort);     /* Server port */
    
	/* print out rules */
	puts("=========================== rule ===============================");
	puts("You are provided the first character and the length of the word.");
	puts("Guess and type the word, make sure to press return key.");
	puts("When you got correct word, you earn 3 point.");
	puts("When you got incorrect word, you lose 2 point.");
	puts("You can request a hint by typing 'hint' but you lose 1 point.");
	puts("================================================================");

    /* Establish the connection to the  server */
    if (connect(sock, (struct sockaddr *) &servAddr, sizeof(servAddr)) < 0)
        DieWithError("connect() failed");
    
    while(1) {
        printf("\n"); /* これが無いと"PRESS [ENTER] TO CONTINUE->"が表示されない */
        /* receive question here */
        if ((bytesRcvd = recv(sock, buffer, RCVBUFSIZE - 1, 0)) <= 0) {
            DieWithError("recv() failed");
        }
        buffer[bytesRcvd] = '\0';
        printf("%s\n", buffer);
        
        /* game over */
        if(!strncmp(buffer, "TOTAL", 5)) break;
        
        for(;;) {
            if ( (clntSock = malloc(sizeof(int))) == NULL ) {
                DieWithError("malloc() failed");
            }
            *clntSock = sock;
            pthread_create(&tid, NULL, &sendAnswer, clntSock);
            
            /* receive responce or notification */
            if ((bytesRcvd = recv(sock, buffer, RCVBUFSIZE - 1, 0)) <= 0) {
                DieWithError("recv() failed");
            }
            buffer[bytesRcvd] = '\0';
            printf("%s\n", buffer);
            
            /* check if buffer is notification or not */
            if(!strncmp(buffer, "!!!", 3)) {          /* buffer is notification */
                /* checking if thread is still alive (true if it's alive) */
                if ( pthread_kill(tid, 0) == 0 ) {
                    printf("PRESS [ENTER] TO CONTINUE->");
                }
                break;
            } else if (!strcmp(buffer, "正解")){       /* buffer is correct responce */
                printf("waiting for other clients to join...................\n");
                break;
            } else if (!strcmp(buffer, "間違い")){     /* buffer is wrong responce */
                continue;
            }
            //pthread_join(tid, NULL);
            //free(clntSock);
        }
    }
    printf("THANK YOU\n");
    
    close(sock);
    exit(0);
}

static void* sendAnswer(void *arg)
{
    int connfd;
    char ans[MAXANSLENGTH];
    char message[RCVBUFSIZE];
    int ansLen;
    int bytesRecvd;
    
    connfd = *( (int *) arg );
    free(arg);
    
    printf("type answer-> ");
    fgets(ans, MAXANSLENGTH, stdin);
    ansLen = strlen(ans);
    if ( send(connfd, ans, ansLen, 0) != ansLen ) {
        DieWithError("in sendAnswer(): send() failed");
    }
    return NULL;
}
